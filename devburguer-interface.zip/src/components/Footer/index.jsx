import { Container } from "./style";

export function Footer(){
    return(
        <Container>
            <p>Desenvolvido por DevClub - 2025 - Todos os direitos reservados</p>
        </Container>
    )
}