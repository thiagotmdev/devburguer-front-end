import { Body, Header, Root, Td, Th, Tr } from "./styles";

export const Table = {
    Body,
    Header,
    Root,
    Td,
    Th,
    Tr,
}